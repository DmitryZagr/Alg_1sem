//
//  main.cpp
//  7_2
//
//  Created by Дмитрий  Загребаев on 13.03.16.
//  Copyright © 2016 Дмитрий  Загребаев. All rights reserved.
//

#include <iostream>
#define SIZE (100000)

//struct Node_ {
//    size_t begin;
//    size_t end;
//    Node_* next;
//    
////private:
////    Node_() {begin = 0, end = 0, next = nullptr;};
//};
//
//typedef struct Node_ Node;

template<class T> void Merge(T const *const A, int const nA,
                             T const *const B, int const nB,
                             T *const C)
{ //Выполнить слияние массива A, содержащего nA элементов,
    //  и массива B, содержащего nB элементов.
    //  Результат записать в массив C.
    
    int a(0), b(0); //Номера текущих элементов в массивах A и B
    
    while( a+b < nA+nB ) //Пока остались элементы в массивах
    {
        if( (b>=nB) || ( (a<nA) && (A[a]<=B[b]) ) )
        { //Копирую элемент из массива A
            C[a+b] = A[a];
            ++a;
        } else { //Копирую элемент из массива B
            C[a+b] = B[b];
            ++b;
        }
    }
}


template<class T> void MergeSort(T *const A, int const n)
{ //Отсортировать массив A, содержащий n элементов
    
    if( n < 2 ) return; //Сортировка не нужна
    
    if( n == 2 ) //Два элемента проще поменять местами,
    {            //  если нужно, чем делать слияние
        if( A[0] > A[1] ) { T const t(A[0]); A[0]=A[1]; A[1]=t; }
        return;
    }
    
    MergeSort(A    , n/2  ); //Сортируем первую половину
    MergeSort(A+n/2, n-n/2); //Сортируем вторую половину
    
    T *const B( new T[n] ); //Сюда запишем результат слияния
//    T *const B = new T[n];
    
    Merge(A,n/2, A+n/2,n-n/2, B); //Слияние половин
    
    //Копирование результата слияния в исходный массив:
    for(int i(0); i<n; ++i) A[i]=B[i];
    
    delete[] B; //Удаляем временный буфер
}


class List {
    
private:
    
    List *head = nullptr;
    List *next = nullptr;
    size_t begin = 0;
    size_t end = 0;
    
public:
    List();
//    List( size_t begin, size_t end);
    ~List();
    
public:
    List* add(size_t begin, size_t end);
    bool isEmpty();
    void show();
};

void readNumber(List* list);
size_t getCountOfRequests(const size_t *arr);

int main(int argc, const char * argv[]) {
    
    List *listOfRequests = new List();
    
//    listOfRequests->add(<#size_t end#>, <#size_t begin#>)
    
    readNumber(listOfRequests);
    
    listOfRequests->show();
    
//    size_t* arr = nullptr;
    
//    readNumber(&arr);
    
    return 0;
}


/*------------------------------------------------------------------------------------------------*/

void readNumber(List* list) {
    
    size_t end = 0;
    size_t begin = 0;
    
    while (true) {
        
        std::cin >> begin >> end;
        if (std::cin.fail()) {
            break;
        }
        
        list->add(begin, end);
    }
    
    
    
//    *arr = (size_t*)malloc(sizeof(size_t) * SIZE);
//    memset(*arr, 0, sizeof(size_t) * SIZE);
//    size_t iter = 1;
//    size_t countOfElems = 0;
//    
//    while (1) {
//        std::cin >> (*arr)[iter] >> (*arr)[iter + 1];
//        if (std::cin.fail()) {
//            break;
//        }
//        countOfElems += 2;
//        iter += 2;
//    }
//    
//    **arr = iter - 1;
    
//    return list;
}

/*------------------------------------------------------------------------------------------------*/

//size_t getCountOfRequests(const size_t *arr) {
//    for (size_t iter = 0; iter <= *arr; iter++) {
//        <#statements#>
//    }
//}

/*------------------------------------------------------------------------------------------------*/



/*------------------------------------------------------------------------------------------------*/



/*------------------------------------------------------------------------------------------------*/



/*------------------------------------------------------------------------------------------------*/



/*------------------------------------------------------------------------------------------------*/



/*------------------------------------------------------------------------------------------------*/

List::List() {
    this->head = nullptr;
    this->next = nullptr;
    this->end = 0;
    this->begin = 0;
}

/*------------------------------------------------------------------------------------------------*/

List::~List() {
    
    List *tmp = nullptr;
    
    while (this->head) {
        tmp = head->next;
        delete head;
        head = tmp;
    }
}



/*------------------------------------------------------------------------------------------------*/

List* List::add(size_t begin, size_t end) {
    
    List *node = new List();
    node->end = end;
    node->begin = begin;
    
    if (this->head == nullptr) {
        this->head = node;
    } else {
        
        node->next = this->head;
        this->head = node;
        
        std::cout << "lol";

    }
    
    return this;
    
}

bool List::isEmpty() {
    return head == nullptr ? true : false;
}

/*------------------------------------------------------------------------------------------------*/

void List::show() {
    List *tmp = this->head;
    
    while (tmp) {
        std:: cout << tmp->begin << tmp->end << std::endl;
        tmp = tmp->next;
    }
}

/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------*/


/*------------------------------------------------------------------------------------------------*/


/*------------------------------------------------------------------------------------------------*/


/*------------------------------------------------------------------------------------------------*/


/*------------------------------------------------------------------------------------------------*/


/*------------------------------------------------------------------------------------------------*/
